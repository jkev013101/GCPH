﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataTable = System.Data.DataTable;

namespace GCPH.Payroll
{
    public partial class FormAdditionalPay : Form
    {
        public FormAdditionalPay()
        {
            InitializeComponent();
            LoadList();
            LoadData();
        }

        private void FormAdditionalPay_Load(object sender, EventArgs e)
        {
            this.ActiveControl = txtEmpID;
            btnUpdate.Enabled = false;
            btnRemove.Enabled = false;
        }
        Connection con = new Connection();

        private void LoadList()
        {
            dataGridView2.DataSource = null;
            con.dataGet("SELECT ID, Name FROM Employee");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            dataGridView2.DataSource = dt;
        }

        private void LoadData()
        {
            dataGridView1.DataSource = null;
            con.dataGet("SELECT Employee.Name,AdditionalPay.* FROM Employee INNER JOIN AdditionalPay ON Employee.ID  = AdditionalPay.ID");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text))
            {
                LoadList();
            }
            else
            {

                con.dataGet("SELECT TOP 10 ID,Name FROM Employee WHERE Name LIKE '" + txtName.Text + "%'");
                DataTable dt = new DataTable();
                con.sda.Fill(dt);
                dataGridView2.DataSource = dt;

            }
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtEmpID.Text = dataGridView2.SelectedRows[0].Cells[0].Value.ToString();
                txtName.Text = dataGridView2.SelectedRows[0].Cells[1].Value.ToString();
                txtDes.Focus();
                txtEmpID.Enabled = false;
                txtName.Enabled = false;
            }
        }

        private void txtEmpID_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtEmpID.Text))
            {
                LoadList();
            }
            else
            {

                con.dataGet("SELECT TOP 10 ID,Name FROM Employee WHERE ID LIKE '" + txtEmpID.Text + "%'");
                DataTable dt = new DataTable();
                con.sda.Fill(dt);
                dataGridView2.DataSource = dt;

            }
        }

        private void txtEmpID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtEmpID.Text = dataGridView2.SelectedRows[0].Cells[0].Value.ToString();
                txtName.Text = dataGridView2.SelectedRows[0].Cells[1].Value.ToString();
                txtDes.Focus();
                txtEmpID.Enabled = false;
                txtName.Enabled = false;
            }

        }

        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {

            txtEmpID.Text = dataGridView2.SelectedRows[0].Cells[0].Value.ToString();
            txtName.Text = dataGridView2.SelectedRows[0].Cells[1].Value.ToString();
            txtDes.Focus();
            txtEmpID.Enabled = false;
            txtName.Enabled = false;

        }

        private void ClearData()
        {
            txtEmpID.Clear();
            txtName.Clear();
            txtDes.Clear();
            txtAmount.Clear();
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
            btnRemove.Enabled = false;
            txtEmpID.Enabled = true;
            txtName.Enabled = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private bool ifEmployeeExists(string empID)
        {
            con.dataGet("Select 1 from AdditionalPay WHERE ID ='" + empID + "'");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ifEmployeeExists(txtEmpID.Text))
            {
                MessageBox.Show("Record of the Employee Rates already exists");
            }
            else
            {
                if (string.IsNullOrEmpty(txtDes.Text))
                {
                    txtDes.Text = "N/A";
                }
                con.dataSend("INSERT INTO AdditionalPay (ID, Description, Amount) VALUES ('"+txtEmpID.Text+"','"+txtDes.Text+"','"+txtAmount.Text+"')");
                LoadData();
                ClearData();
                btnSave.Enabled = true;
                btnUpdate.Enabled = false;
                btnRemove.Enabled = false;

                
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearch.Text))
            {
                LoadData();
            }
            else
            {
                con.dataGet("SELECT TOP 10 Employee.Name,AdditionalPay.* FROM Employee INNER JOIN AdditionalPay ON Employee.ID  = AdditionalPay.ID WHERE Name LIKE '" + txtSearch.Text + "%'");
                DataTable dt = new DataTable();
                con.sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (dataGridView1.Rows.Count > 0)
                {
                    txtName.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                    txtEmpID.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                    txtDes.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                    txtAmount.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                    btnSave.Enabled = false;
                    btnUpdate.Enabled = true;
                    btnRemove.Enabled = true;
                    txtEmpID.Enabled = false;
                    txtName.Enabled = false;
                    txtSearch.Clear();
                }


            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtName.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txtEmpID.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txtDes.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            txtAmount.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            btnSave.Enabled = false;
            btnUpdate.Enabled = true;
            btnRemove.Enabled = true;
            txtEmpID.Enabled = false;
            txtName.Enabled = false;
            txtSearch.Clear();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to update?", "Update", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {

                if (string.IsNullOrEmpty(txtDes.Text))
                {
                    txtDes.Text = "N/A";
                }
                con.dataSend("UPDATE AdditionalPay SET Description ='"+txtDes.Text+"', Amount ='"+txtAmount.Text+"' WHERE ID = '" + txtEmpID.Text + "'");
                MessageBox.Show("Successfully uptaded", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                ClearData();
                btnSave.Enabled = true;
                btnUpdate.Enabled = false;
                btnRemove.Enabled = false;
                txtEmpID.Enabled = true;
                txtName.Enabled = true;
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to remove?", "Remove", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                con.dataSend("DELETE FROM AdditionalPay WHERE ID = '" + txtEmpID.Text + "'");
                LoadData();
                ClearData();
                btnSave.Enabled = true;
                btnUpdate.Enabled = false;
                btnRemove.Enabled = false;
                txtEmpID.Enabled = true;
                txtName.Enabled = true;
            }
        }
    }
}
