﻿namespace GCPH.Payroll
{
    partial class Form13thMonthPay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form13thMonthPay));
            this.btnGenerate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbYear = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dgID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgMonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgGrossPay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgTaxRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgSSS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPhilhealth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPagibig = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgLateUT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgLoan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgBond = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgHairnet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgOther = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgNetPay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGenerate
            // 
            this.btnGenerate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerate.Location = new System.Drawing.Point(12, 12);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(97, 29);
            this.btnGenerate.TabIndex = 1;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(144, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 24;
            this.label1.Text = "Year:";
            // 
            // cmbYear
            // 
            this.cmbYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYear.FormattingEnabled = true;
            this.cmbYear.Location = new System.Drawing.Point(204, 15);
            this.cmbYear.Name = "cmbYear";
            this.cmbYear.Size = new System.Drawing.Size(116, 24);
            this.cmbYear.TabIndex = 25;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgID,
            this.dgName,
            this.dgMonth,
            this.dgYear,
            this.dgGrossPay,
            this.dgTaxRate,
            this.dgSSS,
            this.dgPhilhealth,
            this.dgPagibig,
            this.dgLateUT,
            this.dgLoan,
            this.dgBond,
            this.dgHairnet,
            this.dgOther,
            this.dgNetPay});
            this.dataGridView1.Location = new System.Drawing.Point(13, 47);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1068, 559);
            this.dataGridView1.TabIndex = 26;
            // 
            // dgID
            // 
            this.dgID.HeaderText = "ID";
            this.dgID.MinimumWidth = 6;
            this.dgID.Name = "dgID";
            this.dgID.ReadOnly = true;
            this.dgID.Width = 125;
            // 
            // dgName
            // 
            this.dgName.HeaderText = "Name";
            this.dgName.MinimumWidth = 6;
            this.dgName.Name = "dgName";
            this.dgName.ReadOnly = true;
            this.dgName.Width = 175;
            // 
            // dgMonth
            // 
            this.dgMonth.HeaderText = "Month";
            this.dgMonth.MinimumWidth = 6;
            this.dgMonth.Name = "dgMonth";
            this.dgMonth.ReadOnly = true;
            this.dgMonth.Width = 125;
            // 
            // dgYear
            // 
            this.dgYear.HeaderText = "Year";
            this.dgYear.MinimumWidth = 6;
            this.dgYear.Name = "dgYear";
            this.dgYear.ReadOnly = true;
            this.dgYear.Width = 125;
            // 
            // dgGrossPay
            // 
            this.dgGrossPay.HeaderText = "Gross Pay";
            this.dgGrossPay.MinimumWidth = 6;
            this.dgGrossPay.Name = "dgGrossPay";
            this.dgGrossPay.ReadOnly = true;
            this.dgGrossPay.Width = 125;
            // 
            // dgTaxRate
            // 
            this.dgTaxRate.HeaderText = "Withholding Tax";
            this.dgTaxRate.MinimumWidth = 6;
            this.dgTaxRate.Name = "dgTaxRate";
            this.dgTaxRate.ReadOnly = true;
            this.dgTaxRate.Width = 150;
            // 
            // dgSSS
            // 
            this.dgSSS.HeaderText = "S.S.S";
            this.dgSSS.MinimumWidth = 6;
            this.dgSSS.Name = "dgSSS";
            this.dgSSS.ReadOnly = true;
            this.dgSSS.Width = 125;
            // 
            // dgPhilhealth
            // 
            this.dgPhilhealth.HeaderText = "Phil health";
            this.dgPhilhealth.MinimumWidth = 6;
            this.dgPhilhealth.Name = "dgPhilhealth";
            this.dgPhilhealth.ReadOnly = true;
            this.dgPhilhealth.Width = 125;
            // 
            // dgPagibig
            // 
            this.dgPagibig.HeaderText = "Pag-ibig";
            this.dgPagibig.MinimumWidth = 6;
            this.dgPagibig.Name = "dgPagibig";
            this.dgPagibig.ReadOnly = true;
            this.dgPagibig.Width = 125;
            // 
            // dgLateUT
            // 
            this.dgLateUT.HeaderText = "Late/Undertime";
            this.dgLateUT.MinimumWidth = 6;
            this.dgLateUT.Name = "dgLateUT";
            this.dgLateUT.ReadOnly = true;
            this.dgLateUT.Width = 125;
            // 
            // dgLoan
            // 
            this.dgLoan.HeaderText = "Loan";
            this.dgLoan.MinimumWidth = 6;
            this.dgLoan.Name = "dgLoan";
            this.dgLoan.ReadOnly = true;
            this.dgLoan.Width = 125;
            // 
            // dgBond
            // 
            this.dgBond.HeaderText = "Bond Deposit";
            this.dgBond.MinimumWidth = 6;
            this.dgBond.Name = "dgBond";
            this.dgBond.ReadOnly = true;
            this.dgBond.Width = 125;
            // 
            // dgHairnet
            // 
            this.dgHairnet.HeaderText = "Hairnet/Facemask";
            this.dgHairnet.MinimumWidth = 6;
            this.dgHairnet.Name = "dgHairnet";
            this.dgHairnet.ReadOnly = true;
            this.dgHairnet.Width = 125;
            // 
            // dgOther
            // 
            this.dgOther.HeaderText = "Other Deductions";
            this.dgOther.MinimumWidth = 6;
            this.dgOther.Name = "dgOther";
            this.dgOther.ReadOnly = true;
            this.dgOther.Width = 125;
            // 
            // dgNetPay
            // 
            this.dgNetPay.HeaderText = "Net Pay";
            this.dgNetPay.MinimumWidth = 6;
            this.dgNetPay.Name = "dgNetPay";
            this.dgNetPay.ReadOnly = true;
            this.dgNetPay.Width = 125;
            // 
            // Form13thMonthPay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 653);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.cmbYear);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnGenerate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form13thMonthPay";
            this.Text = "13th Month Pay";
            this.Load += new System.EventHandler(this.Form13thMonthPay_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbYear;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgMonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgGrossPay;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTaxRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgSSS;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPhilhealth;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPagibig;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgLateUT;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgLoan;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgBond;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgHairnet;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgOther;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNetPay;
    }
}