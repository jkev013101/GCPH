﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCPH.Payroll
{
    public partial class Form13thMonthPay : Form
    {
        public Form13thMonthPay()
        {
            InitializeComponent();
        }
        float Rate = 0;
        float PresentDays = 0;

        float grosspay = 0;

        Connection con = new Connection();

        private void Form13thMonthPay_Load(object sender, EventArgs e)
        {
            cmbYear.Items.Add((DateTime.Now.Year) - 1);
            cmbYear.Items.Add((DateTime.Now.Year));
            cmbYear.Items.Add((DateTime.Now.Year) + 1);
            cmbYear.SelectedItem = cmbYear.Items[1];
        }
        
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            con.dataGet("SELECT ID, Year FROM Attendance WHERE Year = '" + cmbYear.Text + "' GROUP BY ID, Year");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    con.dataGet("SELECT EmpSalary.Rate , SUM (PresentDays) AS Present_Days FROM Attendance INNER JOIN EmpSalary ON Attendance.ID = EmpSalary.ID WHERE Attendance.ID = '" + row["ID"].ToString() + "' AND Attendance.Year = '" + cmbYear.Text+"' GROUP BY Attendance.ID, Attendance.Year, EmpSalary.Rate;");
                    DataTable dt1 = new DataTable();
                    con.sda.Fill(dt1);

                    foreach (DataRow row1 in dt1.Rows)
                    { 
                        Rate = float.Parse(row1["Rate"].ToString());
                        PresentDays = float.Parse(row1["Present_Days"].ToString());

                        float grosspay1 = (PresentDays * 26)/360;
                        
                        grosspay = grosspay1 * Rate;
                        con.dataSend("DELETE FROM [13thMonthPay]  WHERE ID = '" + row["ID"].ToString() + "' AND Year = '" + cmbYear.Text+"'");

                        con.dataSend("INSERT INTO [13thMonthPay] (ID, Year, GrossPay) VALUES ('"+row["ID"].ToString()+ "','" + cmbYear.Text + "','"+grosspay+"')");
                        LoadData();
                    }
                      
                }
            }
            else
            {
                MessageBox.Show("Cannot be process!");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LoadData()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            con.dataGet("SELECT [13thMonthPay].*, Employee.Name FROM [13thMonthPay] INNER JOIN Employee ON [13thMonthPay].ID = Employee.ID WHERE Year = '" + cmbYear.Text+"'");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    int n = dataGridView1.Rows.Add();
                    dataGridView1.Rows[n].Cells["dgID"].Value = row["ID"].ToString();
                    dataGridView1.Rows[n].Cells["dgName"].Value = row["Name"].ToString();
                    dataGridView1.Rows[n].Cells["dgYear"].Value = row["Year"].ToString();
                    dataGridView1.Rows[n].Cells["dgGrossPay"].Value = row["GrossPay"].ToString();
                }
            }
        }

        private void cmbYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            con.dataGet("SELECT [13thMonthPay].*, Employee.Name FROM [13thMonthPay] INNER JOIN Employee ON [13thMonthPay].ID = Employee.ID WHERE Year = '" + cmbYear.Text + "'");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    int n = dataGridView1.Rows.Add();
                    dataGridView1.Rows[n].Cells["dgID"].Value = row["ID"].ToString();
                    dataGridView1.Rows[n].Cells["dgName"].Value = row["Name"].ToString();
                    dataGridView1.Rows[n].Cells["dgYear"].Value = row["Year"].ToString();
                    dataGridView1.Rows[n].Cells["dgGrossPay"].Value = row["GrossPay"].ToString();
                }
            }
        }
    }
}
