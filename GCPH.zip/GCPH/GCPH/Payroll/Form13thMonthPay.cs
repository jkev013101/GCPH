﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCPH.Payroll
{
    public partial class Form13thMonthPay : Form
    {
        public Form13thMonthPay()
        {
            InitializeComponent();
        }

        private void Form13thMonthPay_Load(object sender, EventArgs e)
        {
            cmbYear.Items.Add((DateTime.Now.Year) - 1);
            cmbYear.Items.Add((DateTime.Now.Year));
            cmbYear.Items.Add((DateTime.Now.Year) + 1);
            cmbYear.SelectedItem = cmbYear.Items[1];
        }
    }
}
