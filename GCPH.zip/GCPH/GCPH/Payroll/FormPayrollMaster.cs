﻿

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCPH.Payroll
{
    public partial class FormPayrollMaster : Form
    {
        public FormPayrollMaster()
        {
            InitializeComponent();
            
        }
        float Rate = 0;
        float RatePerHour = 0;
        float OTrate = 0;

        float PresentDays = 0;
        float Absents = 0;
        float Overtime = 0;
        float Undertime = 0;
        float Late = 0;
        float RegularHoliday = 0;
        float SpecialHoliday = 0;

        float AddPay = 0;

        float Bond_Deposit = 0;
        float Medical = 0;
        float Loan = 0;
        float Facemask = 0;
        float Other = 0;

        float grosspay = 0;
        float netpay = 0;

        Connection con = new Connection();
        
        private void FormPayrollMaster_Load(object sender, EventArgs e)
        {
            cmbYear.Items.Add((DateTime.Now.Year) - 1);
            cmbYear.Items.Add((DateTime.Now.Year));
            cmbYear.Items.Add((DateTime.Now.Year) + 1);
            cmbYear.SelectedItem = cmbYear.Items[1];
        }
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            // Declare an array
            string[] cutoff1;
            string[] cutoff2;

            cutoff1 = new string[]{ "January 1st cutoff", "February 1st cutoff", "March 1st cutoff", "April 1st cutoff", "May 1st cutoff", "June 1st cutoff", "July 1st cutoff", "August 1st cutoff", "September 1st cutoff", "October 1st cutoff", "November 1st cutoff", "December 1st cutoff"};
            cutoff2 = new string[] { "January 2nd cutoff", "February 2nd cutoff", "March 2nd cutoff", "April 2nd cutoff", "May 2nd cutoff", "June 2nd cutoff", "July 2nd cutoff", "August 2nd cutoff", "September 2nd cutoff", "October 2nd cutoff", "November 2nd cutoff", "December 2nd cutoff" };

            for (int i = 0; i < cutoff1.Length; i++)
            {
                if (cutoff1[i] == cmbMonth.Text) 
                { 
            
                    con.dataGet("SELECT * FROM Attendance WHERE Year = '"+cmbYear.Text+"' AND Month = '"+cmbMonth.Text+"'");
                    DataTable dt = new DataTable();
                    con.sda.Fill(dt);
                    if(dt.Rows.Count > 0)
                    {
                        foreach (DataRow  row in dt.Rows)
                        {
                           
                            con.dataGet(@"SELECT 
                            es.ID,
                            es.Rate,
                            es.RatePerHour,
                            es.OTRate,
                            d.Bond_Deposit,
                            d.Medical,
                            d.Other_Deduction,
                            d.[Facemask/Hairnet],
                            d.Loan,
                            a.PresentDays,
                            a.Absents,
                            a.RegularHoliday,
                            a.SpecialHoliday,
                            a.OvertimeHours,
                            a.UndertimeHours,
                            a.LateHours,
                            ap.Amount
                            FROM EmpSalary AS es INNER JOIN Deductions AS d ON es.ID = d.ID
                            INNER JOIN AdditionalPay AS ap ON d.ID = ap.ID
                            INNER JOIN Attendance AS a ON ap.ID = a.ID
                            WHERE a.Year = '" + cmbYear.Text+"' AND a.Month = '"+cmbMonth.Text+"' AND a.ID = '" + row["ID"].ToString() +"'");
                            DataTable dt1 = new DataTable();
                            con.sda.Fill(dt1);
                            foreach (DataRow row1 in dt1.Rows)
                            { 
                                Rate = float.Parse(row1["Rate"].ToString());
                                RatePerHour = float.Parse(row1["RatePerHour"].ToString());
                                OTrate = float.Parse(row1["OTRate"].ToString());

                                PresentDays = float.Parse(row1["PresentDays"].ToString());
                                Absents = float.Parse(row1["Absents"].ToString());
                                Overtime = float.Parse(row1["OvertimeHours"].ToString());
                                Undertime = float.Parse(row1["UndertimeHours"].ToString());
                                Late = float.Parse(row1["LateHours"].ToString());
                                RegularHoliday = float.Parse(row1["RegularHoliday"].ToString());
                                SpecialHoliday = float.Parse(row1["SpecialHoliday"].ToString());

                                Bond_Deposit = float.Parse(row1["Bond_Deposit"].ToString());
                                Medical = float.Parse(row1["Medical"].ToString());
                                Other = float.Parse(row1["Other_Deduction"].ToString());
                                Facemask = float.Parse(row1["Facemask/Hairnet"].ToString());
                                Loan = float.Parse(row1["Loan"].ToString());

                                AddPay = float.Parse(row1["Amount"].ToString());

                                float BasicPay = PresentDays * Rate;
                                float OTpay = (RatePerHour*Overtime)+(OTrate*Overtime);

                                double rph = RatePerHour * 0.8889;
                                float UTLateCharge = (Late + Undertime) * (float)rph;

                                double regholidaypay = (RegularHoliday * Rate) * 1;
                                double spholidaypay = (SpecialHoliday * Rate) * 0.30;

                                float HolidayPay = (float)regholidaypay+ (float)spholidaypay;

                                grosspay = BasicPay + OTpay + AddPay + HolidayPay;

                                con.dataGet("SELECT SSS.EE FROM SSS WHERE Minimum <= '"+ grosspay+ "' AND Maximum >= '"+ grosspay+"'");
                                DataTable dt2 = new DataTable();
                                con.sda.Fill(dt2);

                                float SSS = float.Parse(dt2.Rows[0]["EE"].ToString());

                                float Pagibig = 0;

                                float Philhealth = 0;

                                con.dataGet("SELECT TaxTrain.Rate, TaxTrain.Amount FROM TaxTrain WHERE Minimum <= '" + grosspay + "' AND Maximum >= '" + grosspay + "'");
                                DataTable dt3 = new DataTable();
                                con.sda.Fill(dt3);

                                float taxamount = float.Parse(dt3.Rows[0]["Amount"].ToString());
                                float taxrate = float.Parse(dt3.Rows[0]["Rate"].ToString());

                                float tax1 = grosspay * taxrate;

                                float tax = tax1 + taxamount;

                                float deductions = tax + Philhealth + Pagibig + SSS +  Bond_Deposit + Medical + Other + Facemask + Loan + UTLateCharge;

                                netpay = grosspay - deductions;

                                con.dataSend("DELETE FROM Payroll WHERE ID = '" + row1["ID"].ToString() + "' AND Year = '" + cmbYear.Text+"' AND Month = '"+cmbMonth.Text+"'");

                                con.dataSend("INSERT INTO Payroll (ID, Month, Year, Gross_Pay, Late_UT, Loan, Bond_Deposit, Tax_Rate, SSS, Philhealth, Pagibig, Hairnet_Facemask, Other_Deductions, Net_Pay) VALUES ('" + row1["ID"].ToString() + "','" + cmbMonth.Text + "','" + cmbYear.Text + "','" + grosspay + "','" + UTLateCharge + "','" + Loan + "','" + Bond_Deposit + "','" + tax + "','" + SSS + "','" + Philhealth + "','" + Pagibig + "','" + Facemask + "','" + Other + "','" + netpay + "')");
                                //MessageBox.Show("Successfully Generated", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadData();
                            
                                
                            }
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("Cannot be process!");
                        
                    }

                }
                else if (cutoff2[i] == cmbMonth.Text)
                {

                    con.dataGet("SELECT * FROM Attendance WHERE Year = '" + cmbYear.Text + "' AND Month = '" + cmbMonth.Text + "'");
                    DataTable dt = new DataTable();
                    con.sda.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            con.dataGet(@"SELECT
                            es.ID,
                            es.Rate,
                            es.RatePerHour,
                            es.OTRate,
                            d.Bond_Deposit,
                            d.Medical,
                            d.Other_Deduction,
                            d.[Facemask/Hairnet],
                            d.Loan,
                            a.PresentDays,
                            a.Absents,
                            a.RegularHoliday,
                            a.SpecialHoliday,
                            a.OvertimeHours,
                            a.UndertimeHours,
                            a.LateHours,
                            ap.Amount
                            FROM EmpSalary AS es INNER JOIN Deductions AS d ON es.ID = d.ID 
                            INNER JOIN AdditionalPay AS ap ON d.ID = ap.ID
                            INNER JOIN Attendance AS a ON ap.ID = a.ID
                            WHERE a.Year = '" + cmbYear.Text + "' AND a.Month = '" + cmbMonth.Text + "' AND a.ID = '" + row["ID"].ToString() + "'");
                            DataTable dt1 = new DataTable();
                            con.sda.Fill(dt1);

                            foreach (DataRow row1 in dt1.Rows) 
                            {
                                Rate = float.Parse(row1["Rate"].ToString());
                                RatePerHour = float.Parse(row1["RatePerHour"].ToString());
                                OTrate = float.Parse(row1["OTRate"].ToString());

                                PresentDays = float.Parse(row1["PresentDays"].ToString());
                                Absents = float.Parse(row1["Absents"].ToString());
                                Overtime = float.Parse(row1["OvertimeHours"].ToString());
                                Undertime = float.Parse(row1["UndertimeHours"].ToString());
                                Late = float.Parse(row1["LateHours"].ToString());
                                RegularHoliday = float.Parse(row1["RegularHoliday"].ToString());
                                SpecialHoliday = float.Parse(row1["SpecialHoliday"].ToString());

                                Bond_Deposit = float.Parse(row1["Bond_Deposit"].ToString());
                                Medical = float.Parse(row1["Medical"].ToString());
                                Other = float.Parse(row1["Other_Deduction"].ToString());
                                Facemask = float.Parse(row1["Facemask/Hairnet"].ToString());
                                Loan = float.Parse(row1["Loan"].ToString());

                                AddPay = float.Parse(row1["Amount"].ToString());

                                float BasicPay = PresentDays * Rate;
                                float OTpay = (RatePerHour * Overtime) + (OTrate * Overtime);

                                double rph = RatePerHour * 0.8889;
                                float UTLateCharge = (Late + Undertime) * (float)rph;

                                double regholidaypay = (RegularHoliday * Rate) * 1;
                                double spholidaypay = (SpecialHoliday * Rate) * 0.30;

                                float HolidayPay = (float)regholidaypay + (float)spholidaypay;

                                grosspay = BasicPay + OTpay + AddPay + HolidayPay;

                                float SSS = 0;

                                con.dataGet("SELECT Pagibig.EE FROM Pagibig WHERE Minimum <= '" + grosspay + "' AND Maximum >= '" + grosspay + "'");
                                DataTable dt2 = new DataTable();
                                con.sda.Fill(dt2);

                                float pagibigrate = float.Parse(dt2.Rows[0]["EE"].ToString());

                                float Pagibig = grosspay * pagibigrate;


                                con.dataGet("SELECT Philhealth.EE FROM Philhealth WHERE Minimum <= '" + grosspay + "' AND Maximum >= '" + grosspay + "'");
                                DataTable dt3 = new DataTable();
                                con.sda.Fill(dt3);

                                float philhealthrate = float.Parse(dt3.Rows[0]["EE"].ToString());

                                float Philhealth = grosspay * philhealthrate;

                                con.dataGet("SELECT TaxTrain.Rate, TaxTrain.Amount FROM TaxTrain WHERE Minimum <= '"+grosspay+ "' AND Maximum >= '"+grosspay+"'");
                                DataTable dt4 = new DataTable();
                                con.sda.Fill(dt4);

                                float taxamount = float.Parse(dt4.Rows[0]["Amount"].ToString());
                                float taxrate = float.Parse(dt4.Rows[0]["Rate"].ToString());

                                float tax1 = grosspay * taxrate;

                                float tax = tax1 + taxamount;

                                float deductions = tax + Philhealth + Pagibig + Bond_Deposit + Medical + Other + Facemask + Loan + UTLateCharge;

                                netpay = grosspay - deductions;

                                con.dataSend("DELETE FROM Payroll WHERE ID = '" + row1["ID"].ToString() + "' AND Year = '" + cmbYear.Text + "' AND Month = '" + cmbMonth.Text + "'");

                                con.dataSend("INSERT INTO Payroll (ID, Month, Year, Gross_Pay, Late_UT, Loan, Bond_Deposit, Tax_Rate, SSS, Philhealth, Pagibig, Hairnet_Facemask, Other_Deductions, Net_Pay) VALUES ('" + row1["ID"].ToString() + "','"+cmbMonth.Text+"','"+cmbYear.Text+"','"+grosspay+"','"+UTLateCharge+"','"+Loan+"','"+Bond_Deposit+"','"+tax+"','"+SSS+"','"+Philhealth+"','"+Pagibig+"','"+Facemask+"','"+Other+"','"+netpay+"')");
                                //MessageBox.Show("Successfully Generated", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadData();
                            
                            }
                        }
                    }

                    else
                    {
                        MessageBox.Show("Cannot be process!");
                        
                    }
                }
            }


        }

        void LoadData()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            con.dataGet("SELECT Payroll.*,Employee.Name FROM Employee INNER JOIN Payroll ON Employee.ID = Payroll.ID WHERE Payroll.Year = '"+cmbYear.Text+"' AND Payroll.Month = '"+cmbMonth.Text+"'");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                foreach(DataRow row in dt.Rows)
                {
                    int n = dataGridView1.Rows.Add();
                    dataGridView1.Rows[n].Cells["dgID"].Value = row["ID"].ToString();
                    dataGridView1.Rows[n].Cells["dgName"].Value = row["Name"].ToString();
                    dataGridView1.Rows[n].Cells["dgMonth"].Value = row["Month"].ToString();
                    dataGridView1.Rows[n].Cells["dgYear"].Value = row["Year"].ToString();
                    dataGridView1.Rows[n].Cells["dgGrossPay"].Value = row["Gross_Pay"].ToString();
                    dataGridView1.Rows[n].Cells["dgTaxRate"].Value = row["Tax_Rate"].ToString();
                    dataGridView1.Rows[n].Cells["dgSSS"].Value = row["SSS"].ToString();
                    dataGridView1.Rows[n].Cells["dgPhilhealth"].Value = row["Philhealth"].ToString();
                    dataGridView1.Rows[n].Cells["dgPagibig"].Value = row["Pagibig"].ToString();
                    dataGridView1.Rows[n].Cells["dgLateUT"].Value = row["Late_UT"].ToString();
                    dataGridView1.Rows[n].Cells["dgLoan"].Value = row["Loan"].ToString();
                    dataGridView1.Rows[n].Cells["dgBond"].Value = row["Bond_Deposit"].ToString();
                    dataGridView1.Rows[n].Cells["dgHairnet"].Value = row["Hairnet_Facemask"].ToString();
                    dataGridView1.Rows[n].Cells["dgOther"].Value = row["Other_Deductions"].ToString();
                    dataGridView1.Rows[n].Cells["dgNetPay"].Value = row["Net_Pay"].ToString();

                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmbMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            con.dataGet("SELECT Payroll.*,Employee.Name FROM Employee INNER JOIN Payroll ON Employee.ID = Payroll.ID WHERE Payroll.Year = '"+cmbYear.Text+"' AND Payroll.Month = '"+cmbMonth.Text+"'");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    int n = dataGridView1.Rows.Add();
                    dataGridView1.Rows[n].Cells["dgID"].Value = row["ID"].ToString();
                    dataGridView1.Rows[n].Cells["dgName"].Value = row["Name"].ToString();
                    dataGridView1.Rows[n].Cells["dgMonth"].Value = row["Month"].ToString();
                    dataGridView1.Rows[n].Cells["dgYear"].Value = row["Year"].ToString();
                    dataGridView1.Rows[n].Cells["dgGrossPay"].Value = row["Gross_Pay"].ToString();
                    dataGridView1.Rows[n].Cells["dgTaxRate"].Value = row["Tax_Rate"].ToString();
                    dataGridView1.Rows[n].Cells["dgSSS"].Value = row["SSS"].ToString();
                    dataGridView1.Rows[n].Cells["dgPhilhealth"].Value = row["Philhealth"].ToString();
                    dataGridView1.Rows[n].Cells["dgPagibig"].Value = row["Pagibig"].ToString();
                    dataGridView1.Rows[n].Cells["dgLateUT"].Value = row["Late_UT"].ToString();
                    dataGridView1.Rows[n].Cells["dgLoan"].Value = row["Loan"].ToString();
                    dataGridView1.Rows[n].Cells["dgBond"].Value = row["Bond_Deposit"].ToString();
                    dataGridView1.Rows[n].Cells["dgHairnet"].Value = row["Hairnet_Facemask"].ToString();
                    dataGridView1.Rows[n].Cells["dgOther"].Value = row["Other_Deductions"].ToString();
                    dataGridView1.Rows[n].Cells["dgNetPay"].Value = row["Net_Pay"].ToString();

                }
            }
        }

        private void cmbYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            con.dataGet("SELECT Payroll.*,Employee.Name FROM Employee INNER JOIN Payroll ON Employee.ID = Payroll.ID WHERE Payroll.Year = '" + cmbYear.Text + "' AND Payroll.Month = '" + cmbMonth.Text + "'");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    int n = dataGridView1.Rows.Add();
                    dataGridView1.Rows[n].Cells["dgID"].Value = row["ID"].ToString();
                    dataGridView1.Rows[n].Cells["dgName"].Value = row["Name"].ToString();
                    dataGridView1.Rows[n].Cells["dgMonth"].Value = row["Month"].ToString();
                    dataGridView1.Rows[n].Cells["dgYear"].Value = row["Year"].ToString();
                    dataGridView1.Rows[n].Cells["dgGrossPay"].Value = row["Gross_Pay"].ToString();
                    dataGridView1.Rows[n].Cells["dgTaxRate"].Value = row["Tax_Rate"].ToString();
                    dataGridView1.Rows[n].Cells["dgSSS"].Value = row["SSS"].ToString();
                    dataGridView1.Rows[n].Cells["dgPhilhealth"].Value = row["Philhealth"].ToString();
                    dataGridView1.Rows[n].Cells["dgPagibig"].Value = row["Pagibig"].ToString();
                    dataGridView1.Rows[n].Cells["dgLateUT"].Value = row["Late_UT"].ToString();
                    dataGridView1.Rows[n].Cells["dgLoan"].Value = row["Loan"].ToString();
                    dataGridView1.Rows[n].Cells["dgBond"].Value = row["Bond_Deposit"].ToString();
                    dataGridView1.Rows[n].Cells["dgHairnet"].Value = row["Hairnet_Facemask"].ToString();
                    dataGridView1.Rows[n].Cells["dgOther"].Value = row["Other_Deductions"].ToString();
                    dataGridView1.Rows[n].Cells["dgNetPay"].Value = row["Net_Pay"].ToString();

                }
            }
        }
    }
}
