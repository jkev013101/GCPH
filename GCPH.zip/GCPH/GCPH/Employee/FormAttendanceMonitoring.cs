﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GCPH.Employee
{
    public partial class FormAttendanceMonitoring : Form
    {
        public FormAttendanceMonitoring()
        {
            InitializeComponent();
        }
        Connection con = new Connection();

        private void FormAttendanceMonitoring_Load(object sender, EventArgs e)
        {
            cmbYear.Items.Add((DateTime.Now.Year) - 1);
            cmbYear.Items.Add((DateTime.Now.Year));
            cmbYear.Items.Add((DateTime.Now.Year) + 1);
            cmbYear.SelectedItem = cmbYear.Items[1];
        }

        void LoadData(string condition)
        {
            con.dataGet("SELECT Attendance.*,Employee.Name FROM Employee INNER JOIN Attendance ON Employee.ID  = Attendance.ID " +condition+ "");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow dr in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells["dgID"].Value = dr["ID"].ToString();
                dataGridView1.Rows[n].Cells["dgName"].Value = dr["Name"].ToString();
                dataGridView1.Rows[n].Cells["dgMonth"].Value = dr["Month"].ToString();
                dataGridView1.Rows[n].Cells["dgYear"].Value = dr["Year"].ToString();
                dataGridView1.Rows[n].Cells["dgPresent"].Value = dr["PresentDays"].ToString();
                dataGridView1.Rows[n].Cells["dgAbsent"].Value = dr["Absents"].ToString();
                dataGridView1.Rows[n].Cells["dgOT"].Value = dr["OvertimeHours"].ToString();
                dataGridView1.Rows[n].Cells["dgUT"].Value = dr["UndertimeHours"].ToString();
                dataGridView1.Rows[n].Cells["dgLate"].Value = dr["LateHours"].ToString();
                dataGridView1.Rows[n].Cells["dgReg"].Value = dr["RegularHoliday"].ToString();
                dataGridView1.Rows[n].Cells["dgSp"].Value = dr["SpecialHoliday"].ToString();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadData("WHERE Attendance.Year = '"+cmbYear.Text+"' AND Attendance.Month ='"+cmbMonth.Text+"'");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
