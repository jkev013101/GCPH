﻿namespace GCPH.Employee
{
    partial class FormAttendanceMonitoring
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAttendanceMonitoring));
            this.label4 = new System.Windows.Forms.Label();
            this.cmbMonth = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.cmbYear = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dgID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgMonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPresent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgAbsent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgOT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgUT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgLate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgReg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgSp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(157, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 16);
            this.label4.TabIndex = 18;
            this.label4.Text = "Month Cutoff:";
            // 
            // cmbMonth
            // 
            this.cmbMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMonth.FormattingEnabled = true;
            this.cmbMonth.Items.AddRange(new object[] {
            "January 1st cutoff",
            "January 2nd cutoff",
            "February 1st cutoff",
            "February 2nd cutoff",
            "March 1st cutoff",
            "March 2nd cutoff",
            "April 1st cutoff",
            "April 2nd cutoff",
            "May 1st cutoff",
            "May 2nd cutoff",
            "June 1st cutoff",
            "June 2nd cutoff",
            "July 1st cutoff",
            "July 2nd cutoff",
            "August 1st cutoff",
            "August 2nd cutoff",
            "September 1st cutoff",
            "September 2nd cutoff",
            "October 1st cutoff",
            "October 2nd cutoff",
            "November 1st cutoff",
            "November 2nd cutoff",
            "December 1st cutoff",
            "December 2nd cutoff"});
            this.cmbMonth.Location = new System.Drawing.Point(268, 9);
            this.cmbMonth.Name = "cmbMonth";
            this.cmbMonth.Size = new System.Drawing.Size(166, 24);
            this.cmbMonth.TabIndex = 19;
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(40, 9);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(88, 24);
            this.btnSearch.TabIndex = 20;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // cmbYear
            // 
            this.cmbYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbYear.FormattingEnabled = true;
            this.cmbYear.Location = new System.Drawing.Point(490, 9);
            this.cmbYear.Name = "cmbYear";
            this.cmbYear.Size = new System.Drawing.Size(116, 24);
            this.cmbYear.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(440, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 22;
            this.label1.Text = "Year:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgID,
            this.dgName,
            this.dgMonth,
            this.dgYear,
            this.dgPresent,
            this.dgAbsent,
            this.dgOT,
            this.dgUT,
            this.dgLate,
            this.dgReg,
            this.dgSp});
            this.dataGridView1.Location = new System.Drawing.Point(13, 52);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1078, 608);
            this.dataGridView1.TabIndex = 23;
            // 
            // dgID
            // 
            this.dgID.HeaderText = "ID";
            this.dgID.MinimumWidth = 6;
            this.dgID.Name = "dgID";
            this.dgID.ReadOnly = true;
            this.dgID.Width = 125;
            // 
            // dgName
            // 
            this.dgName.HeaderText = "Name";
            this.dgName.MinimumWidth = 6;
            this.dgName.Name = "dgName";
            this.dgName.ReadOnly = true;
            this.dgName.Width = 125;
            // 
            // dgMonth
            // 
            this.dgMonth.HeaderText = "Month ";
            this.dgMonth.MinimumWidth = 6;
            this.dgMonth.Name = "dgMonth";
            this.dgMonth.ReadOnly = true;
            this.dgMonth.Width = 125;
            // 
            // dgYear
            // 
            this.dgYear.HeaderText = "Year";
            this.dgYear.MinimumWidth = 6;
            this.dgYear.Name = "dgYear";
            this.dgYear.ReadOnly = true;
            this.dgYear.Width = 125;
            // 
            // dgPresent
            // 
            this.dgPresent.HeaderText = "Present Days";
            this.dgPresent.MinimumWidth = 6;
            this.dgPresent.Name = "dgPresent";
            this.dgPresent.ReadOnly = true;
            this.dgPresent.Width = 125;
            // 
            // dgAbsent
            // 
            this.dgAbsent.HeaderText = "Absents";
            this.dgAbsent.MinimumWidth = 6;
            this.dgAbsent.Name = "dgAbsent";
            this.dgAbsent.ReadOnly = true;
            this.dgAbsent.Width = 125;
            // 
            // dgOT
            // 
            this.dgOT.HeaderText = "O.T Hours";
            this.dgOT.MinimumWidth = 6;
            this.dgOT.Name = "dgOT";
            this.dgOT.ReadOnly = true;
            this.dgOT.Width = 125;
            // 
            // dgUT
            // 
            this.dgUT.HeaderText = "U.T hours";
            this.dgUT.MinimumWidth = 6;
            this.dgUT.Name = "dgUT";
            this.dgUT.ReadOnly = true;
            this.dgUT.Width = 125;
            // 
            // dgLate
            // 
            this.dgLate.HeaderText = "Lates";
            this.dgLate.MinimumWidth = 6;
            this.dgLate.Name = "dgLate";
            this.dgLate.ReadOnly = true;
            this.dgLate.Width = 125;
            // 
            // dgReg
            // 
            this.dgReg.HeaderText = "Reg. Holiday";
            this.dgReg.MinimumWidth = 6;
            this.dgReg.Name = "dgReg";
            this.dgReg.ReadOnly = true;
            this.dgReg.Width = 125;
            // 
            // dgSp
            // 
            this.dgSp.HeaderText = "Special Holiday";
            this.dgSp.MinimumWidth = 6;
            this.dgSp.Name = "dgSp";
            this.dgSp.ReadOnly = true;
            this.dgSp.Width = 125;
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(1003, 666);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(88, 33);
            this.btnCancel.TabIndex = 24;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // FormAttendanceMonitoring
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1103, 704);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbYear);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.cmbMonth);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAttendanceMonitoring";
            this.Text = "Attendance Monitoring";
            this.Load += new System.EventHandler(this.FormAttendanceMonitoring_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbMonth;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ComboBox cmbYear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgMonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPresent;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgAbsent;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgOT;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgUT;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgLate;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgReg;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgSp;
    }
}